-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2018 at 04:07 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jaharat_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `18carate`
--

CREATE TABLE `18carate` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Weight(anna)` varchar(10) NOT NULL,
  `price` varchar(40) NOT NULL,
  `store` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `18carate`
--

INSERT INTO `18carate` (`ID`, `Name`, `Weight(anna)`, `price`, `store`) VALUES
('D1', 'Anklet', '1.5', '3762', '19'),
('D2', 'Anklet', '1.5', '3762', '19'),
('D3', 'Anklet', '1', '2508', '19'),
('D4 ', 'Anklet', '2', '5016', '19'),
('D5', 'Anklet', '2.5', '6270', '19'),
('D6', 'Earing', '1.5', '3762', '30'),
('D7', 'Earing', '1.5', '3762', '30'),
('D8', 'Earing', '2', '5016', '30'),
('D9', 'Earing', '1', '2508', '30'),
('D10', 'Earing', '1', '2508', '30'),
('D11', 'Bracelate', '2.5', '6270', '14'),
('D12', 'Bracelate', '4', '10032', '14'),
('D13', 'Bracelate', '3', '7524', '14'),
('D14', 'Bracelate', '1', '3762', '14'),
('D15', 'Bracelate', '2', '5016', '14'),
('D16', 'Bangles', '3', '7524', '20'),
('D17', 'Bangles', '2', '6270', '20'),
('D18', 'Bangles', '4', '10032', '20'),
('D19', 'Bangles', '2', '5016', '20'),
('D20', 'Ring', '1.5', '3762', '19'),
('D21', 'Ring', '0.5', '1254', '19'),
('D22', 'Ring', '2', '5016', '19'),
('D23', 'Nosepin', '0.5', '1254', '23'),
('D24', 'Nosepin', '1', '2508', '23'),
('D25', 'Chain', '3', '7524', '0'),
('d26', 'nuri', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `21carate`
--

CREATE TABLE `21carate` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `weight` varchar(15) NOT NULL,
  `price` varchar(40) NOT NULL,
  `store` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `21carate`
--

INSERT INTO `21carate` (`ID`, `Name`, `weight`, `price`, `store`) VALUES
('E1', 'Bracelate', '4anna', '11300', 15),
('E2', 'Bracelate', '3anna', '8475', 15),
('E3', 'Bracelate', '2.5anna', '7062', 15),
('E4', 'Bracelate', '2anna', '5650', 15),
('E5', 'Bracelate', '2.5anna', '7062', 15),
('E6', 'Bangles', '2anna', '5650', 30),
('E7', 'Bangles', '4anna', '11300', 30),
('E8', 'Bangles', '4anna', '11300', 30),
('E9', 'Bangles', '3anna', '8475', 30),
('E10', 'Bangles', '6anna', '16950', 30),
('E11', 'Nose pin', '0.5anna', '1412', 21),
('E12', 'Nose pin', '1anna', '2825', 21),
('E13', 'Nosepin', '0.5anna', '1412', 20),
('E14', 'Nosepin', '0.5anna', '1412', 20),
('E15', 'Ring', '2anna', '5650', 20),
('E16', 'Ring', '2anna', '5650', 20),
('E17', 'Ring', '1.5anna', '4237', 20),
('E18', 'Ring', '1anna', '2825', 20),
('E19', 'Ring', '1.5anna', '4237', 20),
('E20', 'Ring', '2.5anna', '7062', 20),
('E21', 'Nacklace', '7anna', '19775', 31),
('E22', 'Nacklace', '6anna', '16950', 31),
('E23', 'Nacklace', '6.5anna', '18362', 31),
('E24', 'Nacklace', '7anna', '19775', 31),
('E25', 'Nacklace', '5anna', '14125', 31);

-- --------------------------------------------------------

--
-- Table structure for table `22carate`
--

CREATE TABLE `22carate` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `weight` varchar(20) NOT NULL,
  `price` varchar(40) NOT NULL,
  `store` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `22carate`
--

INSERT INTO `22carate` (`ID`, `Name`, `weight`, `price`, `store`) VALUES
('A1', 'Nacklace', '5ana', '14835', 31),
('A2', 'Nacklace', '4anna', '11868', 31),
('A3', 'Nacklace', '3anna', '8901', 31),
('A4', 'Nacklace', '5anna', '14835', 31),
('A5', 'Nacklace', '2anna', '5934', 31),
('A6', 'Earing', '1anna', '2967', 30),
('A7', 'Earing', '2anna', '5934', 30),
('A8', 'Earing', '0.5anna', '1483', 30),
('A9', 'Nosepin', '0.5anna', '1483', 20),
('A10', 'Nosepin', '1anna', '2967', 20),
('A11', 'Ring', '2anna', '5934', 20),
('A12', 'Ring', '2.5anna', '7418', 20),
('A13', 'Ring', '1.5anna', '4450', 20),
('A14', 'Ring', '1anna', '2957', 20),
('A15', 'Chain', '3anna', '8901', 12),
('A16', 'Chain', '2anna', '5934', 12),
('A17', 'Chain', '2.5anna', '7418', 12),
('A18', 'Chain', '1.5anna', '4450', 12),
('A19', 'Chain', '3anna', '8901', 12),
('A20', 'Bracelate', '3anna', '8901', 15),
('A21', 'Bracelate', '4anna', '11868', 15),
('A22', 'Bangles', '4anna', '11868', 30),
('A23', 'Bangles', '3anna', '8901', 30),
('A24', 'Bangles', '2.5anna', '7418', 30),
('A25', 'Bangles', '2anna', '5934', 30);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
