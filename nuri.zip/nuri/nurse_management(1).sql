-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 07:48 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nurse_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `dutyroster`
--

CREATE TABLE `dutyroster` (
  `Nurse_id` varchar(10) NOT NULL,
  `Ward_no` varchar(5) NOT NULL,
  `1` varchar(10) NOT NULL,
  `2` varchar(10) NOT NULL,
  `3` varchar(10) NOT NULL,
  `4` varchar(10) NOT NULL,
  `5` varchar(10) NOT NULL,
  `6` varchar(10) NOT NULL,
  `7` varchar(10) NOT NULL,
  `8` varchar(10) NOT NULL,
  `9` varchar(10) NOT NULL,
  `10` varchar(10) NOT NULL,
  `11` varchar(10) NOT NULL,
  `12` varchar(10) NOT NULL,
  `13` varchar(10) NOT NULL,
  `14` varchar(10) NOT NULL,
  `15` varchar(10) NOT NULL,
  `16` varchar(10) NOT NULL,
  `17` varchar(10) NOT NULL,
  `18` varchar(10) NOT NULL,
  `19` varchar(10) NOT NULL,
  `20` varchar(10) NOT NULL,
  `21` varchar(10) NOT NULL,
  `22` varchar(10) NOT NULL,
  `23` varchar(10) NOT NULL,
  `24` varchar(10) NOT NULL,
  `25` varchar(10) NOT NULL,
  `26` varchar(10) NOT NULL,
  `27` varchar(10) NOT NULL,
  `28` varchar(10) NOT NULL,
  `29` varchar(10) NOT NULL,
  `30` varchar(10) NOT NULL,
  `31` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dutyroster`
--

INSERT INTO `dutyroster` (`Nurse_id`, `Ward_no`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `14`, `15`, `16`, `17`, `18`, `19`, `20`, `21`, `22`, `23`, `24`, `25`, `26`, `27`, `28`, `29`, `30`, `31`) VALUES
('0101', '1', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0102', '1', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'N'),
('0101', '1', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0102', '1', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'N'),
('0103', '1', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N'),
('0104', '1', 'M', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'D/O', 'E', 'M', 'M', 'E', 'M', 'E', 'E', 'M', 'D/O', 'E', 'M', 'N'),
('0103', '1', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N'),
('0104', '1', 'M', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'D/O', 'E', 'M', 'M', 'E', 'M', 'E', 'E', 'M', 'D/O', 'E', 'M', 'N'),
('0105', '1', 'E', 'E', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M', 'E'),
('0106', '1', 'E', 'E', 'D/O', 'E', 'E', 'E', 'M', 'M', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'M', 'M', 'E', 'M', 'E', 'D/O', 'M', 'E'),
('0107', '1', 'E', 'M', 'D/O', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0108', '1', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'D/O', 'E', 'M', 'E', 'M', 'D/O', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'E'),
('0109', '1', 'CL', 'CL', 'CL', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0110', '1', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'E', 'E', 'E', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M'),
('0111', '1', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'M', 'E', 'M', 'D/O', 'M', 'E', 'M', 'E', 'CL', 'CL', 'CL', 'CL', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M'),
('0112', '1', 'M', 'M', 'E', 'M/O', 'E', 'M', 'E', 'M', 'E', 'E', 'E', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'M', 'M', 'E'),
('0201', '2', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0202', '2', 'CL', 'CL', 'CL', 'M', 'M', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'N/O', 'M', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N'),
('0203', '2', 'M', 'M', 'D/O', 'M', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/0', 'D/O', 'E', 'M', 'E', 'E'),
('0204', '2', 'M', 'M', 'M', 'M', 'E', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'E', 'D/O', 'M', 'M', 'E', 'M', 'D/O', 'M', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0205', '2', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'M', 'E', 'M', 'E', 'E', 'M', 'D/O', 'M'),
('0206', '2', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'E', 'D/O', 'E', 'M', 'E', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'M', 'M', 'D/O', 'M', 'E', 'D/O', 'E'),
('0207', '2', 'E', 'M', 'D/O', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'D/O', 'M', 'E', 'E', 'E', 'D/O', 'M', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'D/O', 'E', 'M'),
('0208', '2', 'E', 'D/O', 'M', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'D/O', 'M', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0209', '2', 'E', 'E', 'E', 'D/O', 'M', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'D/O', 'M'),
('0210', '2', 'E', 'E', 'E', 'D/O', 'E', 'E', 'M', 'M', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'D/O', 'M', 'M', 'D/O', 'M', 'E', 'M', 'E', 'M', 'E', 'M'),
('0301', '3', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0302', '3', 'E', 'E', 'E', 'D/O', 'E', 'E', 'M', 'M', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'E', 'D/O', 'M', 'M', 'D/O', 'M', 'E', 'M', 'E', 'M', 'M'),
('0303', '2', 'E', 'E', 'E', 'D/O', 'E', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'N'),
('0304', '3', 'E', 'D/O', 'M', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'D/O', 'M', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'M', 'M', 'D/O', 'M', 'E', 'D/O', 'E'),
('0305', '3', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'E', 'D/O', 'M', 'E', 'E', 'E', 'D/O', 'M', 'M', 'M', 'E', 'E', 'E', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N'),
('0306', '3', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'E', 'M', 'D/O', 'M', 'E', 'E', 'D/O', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0307', '3', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'E', 'D/O', 'E', 'M', 'E', 'M', 'D/O', 'M', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'E'),
('0308', '3', 'M', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'M', 'M', 'M', 'E', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N'),
('0309', '3', 'E', 'E', 'E', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'D/O', 'M', 'M', 'M', 'D/O', 'M', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0310', '3', 'E', 'D/O', 'M', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'D/O', 'E', 'M', 'E', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M'),
('0401', '4', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'CL', 'CL', 'CL', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0402', '4', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M'),
('0403', '4', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N'),
('0404', '4', 'M', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'D/O', 'E', 'M', 'M', 'E', 'M', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E'),
('0405', '4', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M', 'E', 'E', 'E', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0406', '4', 'E', 'E', 'D/O', 'E', 'E', 'E', 'M', 'M', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'M', 'M', 'E', 'M', 'E', 'D/O', 'E'),
('0407', '4', 'E', 'E', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0408', '4', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'D/O', 'E', 'M', 'E', 'M', 'E', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E'),
('0409', '4', 'CL', 'CL', 'CL', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M', 'E', 'M', 'E', 'M', 'M', 'M', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N'),
('0410', '4', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'E', 'E', 'E', 'M', 'N', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M'),
('0411', '4', 'N', 'N', 'N', 'N', 'N', 'N', 'M', 'D/O', 'M', 'E', 'M', 'D/O', 'M', 'E', 'M', 'E', 'M', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'D/O', 'M'),
('0412', '4', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'E', 'E', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'M', 'M'),
('0501', '5', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M'),
('0502', '5', 'M', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'E', 'E', 'E', 'M', 'M', 'D/O', 'N'),
('0503', '5', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML'),
('0504', '5', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'E', 'E', 'E', 'M', 'M', 'D/O', 'E', 'M', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N'),
('0505', '5', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'M', 'E', 'M', 'D/O', 'M', 'E', 'M', 'E', 'E', 'E', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0506', '5', 'M', 'M', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'M', 'M', 'M', 'M', 'E', 'E', 'E', 'D/O', 'E', 'M', 'M'),
('0507', '5', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'M', 'M', 'E', 'M', 'E', 'D/O', 'E', 'E', 'E', 'E', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'M', 'D/O'),
('0508', '5', 'E', 'E', 'D/O', 'E', 'E', 'E', 'E', 'E', 'M', 'M', 'M', 'D/O', 'E', 'E', 'M', 'N', 'N/O', 'E', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'E'),
('0509', '5', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M', 'N', 'E', 'E', 'E', 'M', 'M', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0510', '5', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M'),
('0511', '5', 'M', 'D/O', 'M', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'M', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'M'),
('0512', '5', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'D/O', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0513', '5', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M', 'E', 'E', 'M', 'D/O', 'E', 'M', 'M', 'E', 'M', 'E', 'E', 'M', 'E', 'E', 'D/O', 'N/O'),
('0601', '6', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M'),
('0602', '6', 'E', 'E', 'D/O', 'E', 'E', 'E', 'M', 'M', 'E', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'M', 'E', 'M', 'E', 'M', 'M', 'D/O', 'M'),
('0603', '6', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E', 'E', 'M', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/0', 'D/O', 'E', 'M', 'E', 'M'),
('0604', '6', '', 'M', 'M', 'M', 'D/O', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'E'),
('0605', '6', 'M', 'D/O', 'M', 'E', 'E', 'M', 'M', 'E', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'E', 'M', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0606', '6', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'M', 'M', 'E', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0607', '6', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'M', 'E', 'E', 'M', 'E', 'E', 'D/O'),
('0608', '6', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'E', 'E', 'M', 'M', 'D/O', 'E', 'M', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'M', 'M', 'M', 'E', 'M', 'E', 'D/O'),
('0609', '6', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML', 'ML'),
('0610', '6', 'D/O', 'E', 'M', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'E', 'D/O', 'M', 'M', 'M', 'E', 'M', 'M', 'D/O', 'N', 'N', 'N', 'N'),
('0701', '7', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M'),
('0702', '7', 'M', 'M', 'D/O', 'M', 'E', 'M', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'D/O', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'N', 'N', 'N', 'N', 'N'),
('0703', '7', 'M', 'M', 'D/O', 'M', 'E', 'E', 'M', 'E', 'D/O', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'M', 'D/O', 'M', 'M', 'D/O', 'M', 'M', 'M', 'M', 'N', 'N', 'N', 'N', 'N'),
('0704', '7', 'E', 'E', 'E', 'D/O', 'M', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'D/O', 'E', 'E', 'E', 'M', 'M', 'M', 'M', 'E', 'D/O', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0705', '7', 'E', 'E', 'E', 'D/O', 'E', 'E', 'M', 'M', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N/O', 'M', 'E', 'D/O', 'M', 'E', 'M', 'E', 'M', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0706', '7', 'E', 'D/O', 'M', 'E', 'M', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'D/O', 'E', 'M', 'E', 'M', 'E', 'M', 'D/O', 'E', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'M', 'M'),
('0708', '7', 'N', 'N', 'N', 'N', 'N', 'N/O', 'M', 'D/O', 'M', 'E', 'M', 'M', 'D/O', 'E', 'M', 'N', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O'),
('0709', '7', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'E', 'M', 'D/O', 'E', 'M', 'E', 'M', 'N', 'E', 'E', 'E', 'E', 'D/O', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'D/O', 'M'),
('0710', '7', 'N', 'N', 'N', 'N', 'N', 'N/O', 'E', 'E', 'D/O', 'E', 'M', 'E', 'M', 'D/O', 'E', 'N', 'E', 'E', 'E', 'E', 'D/O', 'M', 'M', 'D/O', 'M', 'E', 'M', 'E', 'M', 'E', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `nurse_info`
--

CREATE TABLE `nurse_info` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Phone_number` varchar(15) DEFAULT NULL,
  `Gender` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nurse_info`
--

INSERT INTO `nurse_info` (`ID`, `Name`, `Address`, `Phone_number`, `Gender`) VALUES
('0101', 'Chayna Bagum', 'Munshipara 11', '01300000000', 'Female'),
('0101', 'Chayna Bagum', 'Munshipara 11', '01300000000', 'Female'),
('0102', 'Usha Rani', 'Kajolsha 32', '01300000001', 'Female'),
('0103', 'Lucky Bagum', 'Batali 54', '0160000003', 'Female'),
('0104', 'Ripon Kranti', 'Munshipara 11', '01600000004', 'Male'),
('0105', 'Farzana Akter', 'Housing state 12', '01600000005', 'Female'),
('0106', 'Afroza Sultana', 'Housing state 14', '01600000006', 'Female'),
('0107', 'Uma Dey', 'Housing State 32', '01600000101', 'Female'),
('0107', 'Irani Bagum', 'Pathantula 19', '01600000011', 'Female'),
('0109', 'Sweety Bagum', 'Tilagor 11', '01790382998', 'Female'),
('0110', 'Mamtaz Bagum', 'Tilagor 14', '017362652376', 'Female'),
('0111', 'Liza Akter', 'Bagbari 32', '01737782392', 'Female'),
('0112', 'Joshna Bagum', 'Batali 23', '01673787187', 'Female'),
('0102', 'Usha Rani', 'Kajolsha 32', '01300000001', 'Female'),
('0103', 'Lucky Bagum', 'Batali 54', '0160000003', 'Female'),
('0104', 'Ripon Kranti', 'Munshipara 11', '01600000004', 'Male'),
('0105', 'Farzana Akter', 'Housing state 12', '01600000005', 'Female'),
('0106', 'Afroza Sultana', 'Housing state 14', '01600000006', 'Female'),
('0107', 'Uma Dey', 'Housing State 32', '01600000101', 'Female'),
('0107', 'Irani Bagum', 'Pathantula 19', '01600000011', 'Female'),
('0109', 'Sweety Bagum', 'Tilagor 11', '01790382998', 'Female'),
('0110', 'Mamtaz Bagum', 'Tilagor 14', '017362652376', 'Female'),
('0111', 'Liza Akter', 'Bagbari 32', '01737782392', 'Female'),
('0112', 'Joshna Bagum', 'Batali 23', '01673787187', 'Female'),
('0210', 'Safina Akter', 'sraboni 19', '01736666699', 'Female'),
('0201', 'Roshni Ara Bagum', 'kolapara 33', '016000044', 'Female'),
('0202', 'Sumita Rani Dey', 'Kazitula 32', '01600000033', 'Female'),
('0203', 'Reba Khan', 'Munshipara 45', '01624638255', 'Female'),
('0204', 'Kranti Bala Debi', 'kkajolsha 22', '01645987264', 'Female'),
('0205', 'Muktarani Das', 'Amborkhana 02', '016352972309', 'Female'),
('0206', 'Rokaia Bagum', 'Housing state 22', '017455789236', 'Female'),
('0207', 'Beaity Akter', 'jalalabad 22', '01768235190', 'Female'),
('0208', 'Hossna Ara Khatun ', 'Subidbazar 11', '017362652355', 'Female'),
('0209', 'Nasima Akter', 'kolapara 26', '01737782111', 'Female'),
('0210', 'Safina Akter', 'sraboni 19', '01736666699', 'Female'),
('0201', 'Roshni Ara Bagum', 'kolapara 33', '016000044', 'Female'),
('0202', 'Sumita Rani Dey', 'Kazitula 32', '01600000033', 'Female'),
('0203', 'Reba Khan', 'Munshipara 45', '01624638255', 'Female'),
('0204', 'Kranti Bala Debi', 'kkajolsha 22', '01645987264', 'Female'),
('0205', 'Muktarani Das', 'Amborkhana 02', '016352972309', 'Female'),
('0206', 'Rokaia Bagum', 'Housing state 22', '017455789236', 'Female'),
('0207', 'Beaity Akter', 'jalalabad 22', '01768235190', 'Female'),
('0208', 'Hossna Ara Khatun ', 'Subidbazar 11', '017362652355', 'Female'),
('0209', 'Nasima Akter', 'kolapara 26', '01737782111', 'Female'),
('0301', 'Rokaia Khatun', 'Munshipara 17', '01921637499', 'Female'),
('0302', 'jahanara Bagum', 'kolapara 09', '01972726389', 'Female'),
('0303', 'Nasima Khatun ', 'Sraboni 2', '01972463829', 'Female'),
('0304', 'Lovely Bagum', 'kawapara 22', '01726384926', 'Female'),
('0305', 'Reba Talukdar', 'Amborkhana 33', '01926329829', 'Female'),
('0306', 'Jhuma Rani Deb', 'Bagbari 19', '01635297230', 'Female'),
('0307', 'champa Yeasmin', 'Tilagor 33', '01683920472', 'Female'),
('0308', 'Asma Akter', 'jalalabad 11', '01876276999', 'Female'),
('0309', 'Nasima Siddika', 'Batali 39', '01867365209', 'Female'),
('0310', 'Safal Bishash', 'Dariyapara 28', '019761257657', 'Male'),
('0301', 'Rokaia Khatun', 'Munshipara 17', '01921637499', 'Female'),
('0302', 'jahanara Bagum', 'kolapara 09', '01972726389', 'Female'),
('0303', 'Nasima Khatun ', 'Sraboni 2', '01972463829', 'Female'),
('0304', 'Lovely Bagum', 'kawapara 22', '01726384926', 'Female'),
('0305', 'Reba Talukdar', 'Amborkhana 33', '01926329829', 'Female'),
('0306', 'Jhuma Rani Deb', 'Bagbari 19', '01635297230', 'Female'),
('0307', 'champa Yeasmin', 'Tilagor 33', '01683920472', 'Female'),
('0308', 'Asma Akter', 'jalalabad 11', '01876276999', 'Female'),
('0309', 'Nasima Siddika', 'Batali 39', '01867365209', 'Female'),
('0310', 'Safal Bishash', 'Dariyapara 28', '019761257657', 'Male'),
('0401', 'Afroza Sultana', 'Temukhi 12/a', '01821749302', 'Female'),
('0402', 'Taslima Akter', 'Modina Market 32/f', '01821938483', 'Female'),
('0403', 'Shialy Akter', 'Pathantula sarboni 4/A', '01683794588', 'Female'),
('0404', 'Sharmin Akter', 'Kolapara 11/B', '017487998877', 'Female'),
('0405', 'Aminul Islam', 'Jalalabad 13/A', '01623876540', 'Male'),
('0406', 'Layla Bagum', 'Housing State 8/D', '01632788744', 'Female'),
('0407', 'Abdullah All Mamun', 'Tilagor 22', '01678399001', 'Male'),
('0408', 'Rumana Khanom', 'Baluchor 9/C', '01823003388', 'Female'),
('0409', 'Shima Rani', 'Amborklhana 14/f', '01722345674', 'Female'),
('0410', 'MST. Konoklata', 'Batali 39/a', '01829329874', 'Female'),
('0411', 'Zahad Ahmed', 'Medical shapla 22/a', '01921235467', 'male'),
('0412', 'Nipa Akter', 'Eidhga 17/E', '01888823345', 'female'),
('0501', 'Dilip Mandal', 'Temukhi 33/F', '01911198203', 'male'),
('0502', 'Reba Chakrabarty', 'Pathantula sraboni 33/c', '01832324334', 'Female'),
('0503', 'Beauty Akter', 'Tilagor 9/c', '017772223333', 'Female'),
('0504', 'Rojina Akter', 'Bagbari 44', '01921213465', 'Female'),
('0505', 'Paryin Akter', 'Bagbari 02', '01921545498', 'Female'),
('0506', 'Jakirun Nessa', 'Lamabazar 25/d', '01882990034', 'Female'),
('0507', 'Shila Khatum', 'Sadipur 18/b', '01654789504', 'Female'),
('0508', 'Ripa Akter', 'Baluchor 9/d', '01768235144', 'Female'),
('0509', 'Rina Akter', 'Batali 38/b', '01736265277', 'Female'),
('0510', 'Parveen Akter', 'Dariyapara 15/a', '0173778222', 'Female'),
('0511', 'Kabita Rani Deb', 'Medical shapla 9/f', '01993787187', 'Female'),
('0512', 'Kusum Kumari', 'Eidhga 33/a', '01778823345', 'female'),
('0513', 'Joya Proda', 'Dariyapara 19/a', '01929999930', 'female'),
('0601', 'Khadija Islam', 'Temukhi 27/a', '01821749399', 'Female'),
('0602', 'Jannatul Ferdouse', 'Pathantula sraboni 19/c', '01821118483', 'Female'),
('0603', 'Anup Kumar Chy.', 'Munshipara 10/f', '01683798888', 'Male'),
('0604', 'Fredouse Akter', 'Housing state 45', '01726284926', 'Female'),
('0605', 'Lima Poddar', 'kajolsha 9', '01921545455', 'Female'),
('0606', 'Kumari Rubi Saha', 'Lamabazar 35/d', '01635287230', 'Female'),
('0607', 'Shaif Uddin ', 'Pathantula sraboni 44', '01654789533', 'Male'),
('0608', 'Nilima Chakrabarty', 'jalalabad 9/b', '01768235191', 'Female'),
('0609', 'Anamika Mitra', 'Batali 33/b', '01722345676', 'Female'),
('0610', 'Sharifa Akter', 'kolapara 29', '01737782444', 'Female'),
('0701', 'Mitali Dev', 'sraboni 17/a', '01721749302', 'Female'),
('0702', 'Rahima Sultana', 'Modina Market 13/f', '01732324334', 'Female'),
('0703', 'Himani Dev', 'Kazitula 32/a', '01783794588', 'Female'),
('0704', 'Sabina Akter', 'Housing state 9', '01926284926', 'Female'),
('0705', 'Julakha Bagum', 'Bagbari 08/c', '01821545455', 'Female'),
('0706', 'Moslama Khatun', 'Lamabazar 35/d', '01732788744', 'Female'),
('0707', 'Samia Akter', 'Pathantula sraboni 4/a', '01884789533', 'Female'),
('0708', 'Aysha Bagum', 'Tilagor 9/b', '01948235191', 'Female'),
('0709', 'Ritu Charkrabarty', 'Subidbazar 13/d', '01836265233', 'Female'),
('0710', 'Jutika Saha', 'Dariyapara 19/a', '01637782111', 'Female');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
